# Deployement-of-NLP-Model
Deployment of NLP Sensitive Analysis use Case with the help of flask and docker.
